@echo off
echo.
echo ========================================
echo   混合动态多 Agent 系统 - 监控大屏
echo ========================================
echo.
echo 正在启动简约版监控大屏...
echo.

start "" "dashboard-simple.html"

echo.
echo ✅ 监控大屏已在默认浏览器中打开！
echo.
echo 访问地址：http://localhost:5000/dashboard-simple.html
echo.
echo 按任意键退出...
pause >nul
